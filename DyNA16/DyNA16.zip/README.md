#### DyNA16
This MiSite contains material presented at DyNA16
The 2016 Dyalog North American User Meeting
